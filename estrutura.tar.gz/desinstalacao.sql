
drop table if exists devolucaosolicitacaorepasse;
drop sequence if exists devolucaosolicitacaorepasse_sequencial_seq;

drop table if exists autorizacaorepasse;
drop sequence if exists autorizacaorepasse_sequencial_seq;

drop table if exists solicitacaorepasseempnota;
drop sequence if exists solicitacaorepasseempnota_sequencial_seq;

drop table if exists solicitacaorepasse;
drop sequence if exists solicitacaorepasse_sequencial_seq;
